# CK Stands
A 1.21.5+ resource pack to be used on the CubeKrowd server.\
Updates the UI for the Armour Stand Plugin to be much more vissually intuative.

### Before
<img width="504" height="369" alt="image" src="https://github.com/user-attachments/assets/681b867f-1ebb-46a1-9568-4079c8f66156" />

### After
<img width="501" height="370" alt="image" src="https://github.com/user-attachments/assets/dbb807d3-ce3e-42f2-ba7c-61e9ed4cb1c3" />

